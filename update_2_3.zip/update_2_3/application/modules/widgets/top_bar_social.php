<!-- Social media starts -->
        <div class="tb-social pull-right">
            <div class="brand-bg text-right">
                <!-- Brand Icons -->
                <a target="_blank" href="https://www.facebook.com/webhelios" class="facebook"><i class="fa fa-facebook square-2 rounded-1"></i></a>
                <a target="_blank" href="https://twitter.com/webhelios" class="twitter"><i class="fa fa-twitter square-2 rounded-1"></i></a>
                <a target="_blank" href="https://plus.google.com/+webhelios/about" class="google-plus"><i class="fa fa-google-plus square-2 rounded-1"></i></a>
                <a  target="_blank" href="#" class="linkedin"><i class="fa fa-linkedin square-2 rounded-1"></i></a>
                <a target="_blank" href="#" class="pinterest"><i class="fa fa-pinterest square-2 rounded-1"></i></a>
            </div>
        </div>
        <!-- Social media ends -->
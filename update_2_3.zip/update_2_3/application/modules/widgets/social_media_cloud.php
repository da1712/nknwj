<!-- Social media widget -->
<div class="s-widget">
    <h5><i class="fa fa-share color"></i>&nbsp; Social Media</h5>
    <!-- Widgets Content -->
    <div class="widget-content brand-bg">
        <!-- Social Media Icons -->
        <a class="facebook" href="javascript:void(0);"><i class="fa fa-facebook square-3 rounded-1"></i></a>
        <a class="twitter" href="javascript:void(0);"><i class="fa fa-twitter square-3 rounded-1"></i></a>
        <a class="google-plus" href="javascript:void(0);"><i class="fa fa-google-plus square-3 rounded-1"></i></a>
        <a class="linkedin" href="javascript:void(0);"><i class="fa fa-linkedin square-3 rounded-1"></i></a>
        <a class="pinterest" href="javascript:void(0);"><i class="fa fa-pinterest square-3 rounded-1"></i></a>
        <a class="dropbox" href="javascript:void(0);"><i class="fa fa-dropbox square-3 rounded-1"></i></a>
        <a class="foursquare" href="javascript:void(0);"><i class="fa fa-foursquare square-3 rounded-1"></i></a>
        <a class="flickr" href="javascript:void(0);"><i class="fa fa-flickr square-3 rounded-1"></i></a>
        <a class="github" href="javascript:void(0);"><i class="fa fa-github square-3 rounded-1"></i></a>
        <a class="instagram" href="javascript:void(0);"><i class="fa fa-instagram square-3 rounded-1"></i></a>
        <a class="skype" href="javascript:void(0);"><i class="fa fa-skype square-3 rounded-1"></i></a>
        <a class="tumblr" href="javascript:void(0);"><i class="fa fa-tumblr square-3 rounded-1"></i></a>
        <a class="dribbble" href="javascript:void(0);"><i class="fa fa-dribbble square-3 rounded-1"></i></a>
        <a class="youtube" href="javascript:void(0);"><i class="fa fa-youtube square-3 rounded-1"></i></a>
    </div>
</div>
<div style="clear:both"></div>
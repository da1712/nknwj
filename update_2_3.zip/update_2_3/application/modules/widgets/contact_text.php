<!-- Heading -->
                    <h5 class="bold"><i class="fa fa-building-o"></i>  Contact Us</h5>
                    <!-- Foot Item Content -->
                    <div class="foot-item-content address">
                        <!-- Heading -->
                        <h6 class="bold"><i class="fa fa-home"></i>  Webhelios Ltd.</h6>
                        <!-- Paragraph -->
                        <p class="add">
                           67/2 Lorem Ipsum</p>
                        <p class="tel"> <i class="fa fa-phone"></i> Tel : + (88) - 8XX XXX<br>
                        <i class="fa fa-envelope"></i>  Mail : <a href="mailto:support@webhelios.com">support@webhelios.com</a><br>
                        <i class="fa fa-calendar"></i> Business Hours : 9:30 - 5:30</p>
                    </div>
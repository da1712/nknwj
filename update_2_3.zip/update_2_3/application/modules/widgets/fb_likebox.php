<div class="s-widget">
	<!-- Heading -->
	<h5><i class="fa fa-facebook color"></i>  <?php echo lang_key('find_us_on_facebook'); ?></h5>
	<!-- Widgets Content -->

	<iframe id="fb-like-box" src="//www.facebook.com/plugins/likebox.php?href=https%3A%2F%2Fwww.facebook.com%2Fwebhelios&width=330&height=218&colorscheme=light&show_faces=true&header=true&stream=false&show_border=true&appId=194009127410715"  style="border:none; overflow:hidden; height:218px;"></iframe>
	<script type="text/javascript">
		jQuery(document).ready(function(){
			jQuery('#fb-like-box').css('width','100%');
			jQuery('#fb-like-box').css('margin-top','5px');
		});
	</script>
</div>
<div class="clearfix"></div>

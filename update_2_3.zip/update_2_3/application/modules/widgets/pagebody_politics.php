<?php 
$source_id    	= 'all';
$category 	  	= 15;
$sub_category 	= 'all';
$limit 			= 15;
require'pagebody_widget_content.php';
?>
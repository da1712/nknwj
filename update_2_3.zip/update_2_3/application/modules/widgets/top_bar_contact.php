<!-- Contact starts -->
        <div class="tb-contact pull-left">
            <!-- Email -->
            <i class="fa fa-envelope color"></i> &nbsp; <a href="mailto:support@webhelios.com">support@webhelios.com</a>
            &nbsp;&nbsp;
            <!-- Phone -->
            <i class="fa fa-phone color"></i> &nbsp; +1 (342)-(323)-4923
        </div>
        <!-- Contact ends -->
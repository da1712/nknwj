<?php
$isSsl = (strpos('-'.base_url(), 'https://')>0)?'1':'0';
?>
<?php 
$main_news = $post->row_array();
$main_news_url = post_detail_url($main_news);
$source_name = get_source_title_by_id($main_news['source_id']);
$CI = get_instance();
$CI->load->model('admin/content_model');
$source = $CI->content_model->get_source_data_by_id($main_news['source_id']);

$spintax_support = get_settings('global_settings','spintax_support','no');
if($spintax_support=='yes')
{
    $main_news['title'] = spintax_process($main_news['title']);
    $main_news['description'] = spintax_process($main_news['description']);
    $main_news['full_description'] = spintax_process($main_news['full_description']);
}
?>

<div class="page-heading-two">
    <div class="container">
        <h2><?php echo $main_news['title'];?></h2>        
        <div class="clearfix"></div>
    </div>
</div>

<div class="container">

    <!-- Actual content -->
    
        <!-- Block heading two -->
        
        <div class="row">
            <div class="col-md-8 col-sm-12 col-xs-12 content-panel">

                <article  itemscope="">
                    

                    <a class="image-link" title="<?php echo $main_news['title'];?>" href="">
                        <img title="<?php echo $main_news['title'];?>" alt="<?php echo $main_news['title'];?>" class="img-responsive main-news-image" src="<?php echo $main_news['media'];?>">                      
                    </a>
                    
                    <div class="main-news-meta">
                        <span class="news-by">
                            <span class="news-by-title">
                                <?php echo lang_key('news_by');?>:
                            </span>
                            <span class="news-by-body">
                                <a href="<?php echo $main_news_url;?>"><?php echo $source_name;?></a>
                            </span>
                        </span>

                        <span class="news-by">
                            <span class="news-by-title">
                                <?php echo lang_key('on');?>:
                            </span>
                            <span class="news-by-body">
                                <a href="<?php echo $main_news_url;?>"><?php echo translateable_date($main_news['publish_time'])?></a>
                            </span>
                        </span>
                                                            
                        <span class="comments news-by">
                            <span class="news-by-title">
                                <?php echo lang_key('seen_by');?>:
                            </span>
                            <span class="news-by-body">
                                <a href="<?php echo $main_news_url;?>"><i class="fa fa-eye"></i> <?php echo $main_news['total_view'];?></a>
                            </span>
                        </span>                 
                    </div>
                    
                    <h2 class="main-news-big-title"><a title="<?php echo $main_news['title'];?>" href="#"><?php echo $main_news['title'];?></a></h2>
                    
                    <div class="excerpt">
                        <p class="detail">
                        <?php 
                            if((isset($source->grab_full_news) && $source->grab_full_news==1) || $main_news['manual_creation']==1 )
                                $description = $main_news['full_description'];
                            else
                                $description = $main_news['description'];

                            // $description = str_replace('<a href="https://blockads.fivefilters.org">Let\'s block ads!</a>', '', $description);
                            // $description = str_replace('<a href="https://github.com/fivefilters/block-ads/wiki/There-are-no-acceptable-ads">(Why?)</a>', '',$description);

                            $filter_text_list = get_single_option('filter_text_list');
                            $texts = explode(PHP_EOL, $filter_text_list);
                               foreach ($texts as $text) {
                                    $description = str_replace($text,'',$description);
                               }
                            echo $description;
                        ?>
                        </p>
                        <p>
                            <?php 
                            if($main_news['tags']!=''){
                                ?>
                                <div style="font-weight:bold"><?php echo lang_key('tags');?>:</div>
                                <?php
                                $tags = explode(',', $main_news['tags']);
                                foreach ($tags as $tag) {
                                    $tag_url = site_url('show/searchnews/plainkey='.$tag.'|');
                                ?>
                                <a href="<?php echo $tag_url;?>">#<?php echo $tag;?></a>&nbsp;
                                <?php
                                }
                            }
                            ?>
                        </p>
                    </div>
                
                    <?php if($main_news['manual_creation']!=1){?>
                        <?php if(get_settings('global_settings','disable_main_site_link','No')=='No'){?>
                            <a id="main-site-link" href="<?php echo $main_news['link'];?>" target="_blank" class="btn btn-blue" style="width:100%"><?php echo lang_key('read_this_on');?> <?php echo $source_name;?></a>
                        <?php }?>
                    <?php }?>
                    <?php 
                    if($this->config->item('shorten_detail_url')=='yes')
                    $short_url = post_short_url($main_news);

                    if(stripos('-'.$short_url,'https://is.gd/')>0)
                    $short_url = $short_url;    
                    else
                    $short_url = $main_news_url;
                    ?>
                    

                    <?php render_widgets('detail_page');?>

                    <?php

                                $comment_settings = get_settings('global_settings', 'enable_comment', 'No');
                                if($comment_settings == 'Disqus Comment')
                                { 
                                    $disqus_shortname = get_settings('global_settings', 'disqus_shortname', '');

                                ?>
                                <div id="disqus_thread"></div>
                                <script type="text/javascript">
                                    var disqus_shortname = '<?php echo $disqus_shortname; ?>'; // required: replace example with your forum shortname

                                    (function() {
                                        var dsq = document.createElement('script'); dsq.type = 'text/javascript'; dsq.async = true;
                                        dsq.src = '//' + disqus_shortname + '.disqus.com/embed.js';
                                        (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(dsq);
                                    })();
                                </script>
                                <noscript>Please enable JavaScript to view the <a href="http://disqus.com/?ref_noscript">comments powered by Disqus.</a></noscript>
                                <div class="clearfix"></div>
                                
                                <?php 
                                } 
                                ?>

                                <?php 

                                if($comment_settings == 'Facebook Comment')
                                { 
                                    $fb_app_id = get_settings('global_settings', 'fb_comment_app_id', ''); ?>
                                    <style>
                                        .fb-comments, .fb-comments iframe[style] {width: 100% !important;}
                                    </style>
                                    <div id="fb-root"></div>
                                    <script>
                                        var fb_app_id = '<?php echo $fb_app_id; ?>';

                                        (function(d, s, id) {
                                            var js, fjs = d.getElementsByTagName(s)[0];
                                            if (d.getElementById(id)) return;
                                            js = d.createElement(s); js.id = id;
                                            js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&appId=" + fb_app_id + "&version=v2.7";
                                            fjs.parentNode.insertBefore(js, fjs);
                                        }(document, 'script', 'facebook-jssdk'));
                                    </script>

                                    <div style="clear:both;margin-top:10px;"></div>
                                    <div class="fb-comments" data-href="<?php echo post_detail_url($main_news,FALSE);?>" data-numposts="10" data-colorscheme="light"></div>

                                <?php 
                                } 
                                ?>

                </article>

            </div>
            <div class="col-md-4 col-sm-12 col-xs-12">
                <div class="sidebar">

                    <?php render_widgets('right_bar_detail');?>
               </div>
            </div>
        </div>
    
</div>

<div id="external-news-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-dialog-external">
        <div class="modal-content modal-content-external">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title" id="myModalLabel2"><?php echo lang_key('external_viewer'); ?> </h4>
            </div>

            <div class="modal-body">
                <div class="embed-responsive embed-responsive-16by9">
                  <iframe class="embed-responsive-item" src="<?php echo site_url();?>" allowfullscreen></iframe>
                </div>            
            </div>

            <div class="modal-footer">
            </div>
        </div>
    </div>
</div>

<style type="text/css">
.stButton .stFb, .stButton .stTwbutton, .stButton .stMainServices{ height: 23px; } .stButton .stButton_gradient{ height: 23px; }
</style>

<script type="text/javascript">
jQuery(document).ready(function(){
    // added on version 1.4
    var main_img = jQuery('.image-link > img').attr('src');
    var index = main_img.lastIndexOf("/") + 1;
    var filename = main_img.substr(index);
    jQuery('.excerpt img').each(function(){
        var tmp_img = jQuery(this).attr('src');
        if(tmp_img.indexOf(filename)>0)
            jQuery(this).hide();

        if(jQuery(this).width()>300)
            jQuery(this).css('width','100%');
    });

    var iOS = !!navigator.platform && /iPad|iPhone|iPod/.test(navigator.platform);
    var embedAble = false;

    <?php if(get_settings('global_settings','disable_main_site_link','No')=='No'){?>

    var loadUrl = '<?php echo site_url();?>/show/if_embedable';
    jQuery.post(
        loadUrl,
        {'url':$('#main-site-link').attr('href')},
        function(responseText){
          if(responseText=='yes')
          {
            embedAble = true;
          }
        }
    );

    <?php 
    }
    ?>

    $('#main-site-link').click(function(e){
        if(iOS==false && embedAble==true)
        {
            e.preventDefault();
            $('.embed-responsive-item').attr('src',$('#main-site-link').attr('href'));
            $('#external-news-modal').modal('show');            
        }
        
    });
});

</script>

<?php 
if($curr_lang=='ar' || $curr_lang=='fa' || $curr_lang=='he' || $curr_lang=='ur' || get_settings('site_settings','site_direction','ltr')=='rtl')
{
    $rtl = true;
}
else
{
	$rtl = false;
}
?>
<div class="row marquee-holder">
	<div class="col-md-1 col-sm-2 col-xs-3 marquee-heading">
		<?php echo lang_key('latest_news');?>:
	</div>
	<div class="col-md-11 col-sm-10 col-xs-9 marquee-body">
		<?php 
		$source_id    = 'all';
		$category 	  = 'all';
		$sub_category = 'all';
		$limit = 10;

		$CI = get_instance();
		$CI->load->helper('text');
		$CI->load->model('admin/news_model');
		$news_query = $CI->news_model->get_news_by_source_category_subcategory($source_id,$category,$sub_category,$limit);
		?>
		<ul id="marquee" class="marquee" data-direction="<?php echo ($rtl)?'right':'left';?>" dir="ltr">
		  <?php foreach ($news_query->result() as $news) {
		  ?>
			  <li>
			  	<span class="news-by-main">
				    <span class="marquee-news-title">"<?php echo word_limiter($news->title,15);?>"</span> <a href="<?php echo post_detail_url($news);?>"><?php echo lang_key('more');?></a>
			    </span>
			    <?php 
			    $source_name 	= get_source_title_by_id($news->source_id);
			    $source_url 	= source_news_url($news->source_id,$source_name);
			    $date_url 		= date_news_url($news->publish_time);
			    ?>
			    <span class="news-by-marquee">
			    	<span class="news-by-title">
						<?php echo lang_key('news_by');?>:
					</span>
					<span class="news-by-body">
					 <a href="<?php echo $source_url;?>"><?php echo $source_name;?></a>
					</span>
				</span>

				<span class="news-by-marquee">
			    	<span class="news-by-title">
						<?php echo lang_key('on');?>:
					</span>
					<span class="news-by-body">
					 <a href="<?php echo $date_url;?>"><?php echo translateable_date($news->publish_time)?></a>
					</span>
				</span>
				&nbsp;|													
			  </li>		  
		  <?php
		  }
		  ?>
		</ul>
	</div>
</div>

<script type="text/javascript">
	$('#marquee').marquee({pauseOnHover: true,duration: 11000});
</script>
<style type="text/css">
	.marquee-body{
		overflow: hidden;
		height: 39px;
	}
</style>
<?php 

$file 	= './dbc_config/config.xml';

$xmlstr = file_get_contents($file);

$xml 	= simplexml_load_string($xmlstr);

$config	= $xml->xpath('//config');	

$current_version = $config[0]->version;

$current_version = explode('.',$current_version);



?>
<?php $curr_lang = get_current_lang(); ?>



      <div class="page-title">

        <div>

          <h1><i class="fa fa-file-o"></i> <?php echo lang_key_admin('dashboard');?> <div class="version">NewsPilot - version : <?php echo $config[0]->version;?></div></h1>

          <h4><?php echo lang_key_admin('overview_stats_more');?></h4>

        </div>

      </div>


    <div class="row">

      <div class="col-md-7">

        <div class="row">

          <div class="col-md-7">

            <div class="row">

              <div class="col-md-12">

                <div class="tile">

                  <p class="title">

                    NewsPilot - Create Your News Site Easily

                  </p>

                  <p>

                    Create and grab News with styles

                  </p>

                  <div class="img img-bottom">

                    <i class="fa fa-desktop"></i>

                  </div>

                </div>

              </div>

            </div>

            

          </div>

          <div class="col-md-5">

            <div class="row">

              <div class="col-md-12 tile-active">

                <div class="tile tile-magenta">

                  <div class="img img-center">

                    <i class="fa fa-desktop"></i>

                  </div>

                  <p class="title text-center">

                    NewsPilot Admin

                  </p>

                </div>

                <div class="tile tile-blue">

                  <p class="title">

                    NewsPilot - Auto News Grabber Admin

                  </p>

                  <p>

                     NewsPilot is the most complete and easy manageable News script. You can create or grab news using RSS feed and post them in different categories.

                  </p>

                  <div class="img img-bottom">

                    <i class="fa fa-desktop"></i>

                  </div>

                </div>

              </div>

            </div>

            

          </div>


        </div>
        
      </div>

      <div class="col-md-5">

        <div class="row">

          <div class="col-md-6">

            <div class="tile tile-orange">

              <div class="img">

                <i class="fa fa-users"></i>

              </div>

              <div class="content">

                <p class="big">

                  <?php 
                  $CI = get_instance();
                  $CI->load->database();
                  $query = $CI->db->get_where('users',array('status'=>1));
                  echo $query->num_rows();
                  ?>

                </p>

                <p class="title">

                  <?php echo lang_key_admin('users') ?>

                </p>

              </div>

            </div>

          </div>

          <div class="col-md-6">

            <div class="tile tile-dark-blue">

              <div class="img">

                <i class="fa fa-bars"></i>

              </div>

              <div class="content">
                <p class="big">
                 <?php                  
                $this->db->select('COUNT(*) as TOTAL');
                $this->db->from('news'); 
                $this->db->where('status',1);     
                $query = $this->db->get(); 
                  echo $query->row()->TOTAL;
                  ?>
                </p>
                <p class="title">
                  <?php echo lang_key_admin('news');?>
                </p>
              </div>
            </div>
          </div>

          
        </div>
      </div>
    </div>

    <div class="row">
    	<div class="col-md-12">
      		<div class="alert alert-info">
          		Please set the following command from cronjobs tab on your cpanel <br/>
          		php -q <?php echo constant("CRON_PATH").'/index.php';?> 
      		</div>
        </div>
    </div>

    <div class="row">
      <div class="col-md-12">
        <a href="//newspilot.webhelios.com/doc" target="_blank" class="btn btn-info"><?php echo lang_key_admin('see_full_documentation');?></a>
      </div>
    </div> 
<style type="text/css">
  .version{
    font-size: 14px;
    font-style: italic;
    margin:10px 0 0 44px;
  }
</style>

<ul class="list-inline pull-right">
    <li><a href="<?php echo site_url();?>"><?php echo lang_key('home');?></a></li>
    <li><a href="<?php echo site_url('page/about');?>"><?php echo lang_key('about')?></a></li>
    <li><a href="<?php echo site_url('contact');?>"><?php echo lang_key('contact')?></a></li>
</ul>
<?php 
$limit = 5;

$CI = get_instance();
$CI->load->model('admin/news_model');
$news_query = $CI->news_model->get_featured_news($limit);
?>
<div class="s-widget">
    <!-- Heading -->
    <h5><i class="fa fa-building color"></i>&nbsp; <?php echo lang_key('featured_news');?></h5>
    <!-- Widgets Content -->
    <div class="widget-content hot-properties">
        <?php if($news_query->num_rows()<=0){?>
        <div class="alert alert-info"><?php echo lang_key('no_news');?></div>
        <?php }else{?>
        <ul class="list-unstyled">
            <?php 
            foreach ($news_query->result() as $post) {
            ?>
            <li class="col-xs-12 col-sm-6 col-md-12 col-lg-12">
                <!-- Image -->
                <a href="<?php echo post_detail_url($post);?>">
                    <?php if($CI->session->userdata('lazyload')=='yes'){?>
                    <img class="img-responsive img-thumbnail lazy-thumb" src="<?php echo base_url('uploads/images/no-image.jpeg');?>" data-src="<?php echo $post->media;?>" alt="<?php echo $post->title;?>" />
                    <?php }else{?>
                    <img class="img-responsive img-thumbnail"src="<?php echo $post->media;?>" alt="<?php echo $post->title;?>" />
                    <?php }?>
                </a>
                <!-- Heading -->
                <div class="sub-head"><a href="<?php echo post_detail_url($post);?>"><?php echo $post->title;?></a></div>
                <!-- Price -->
                <?php
                $main_news_source = get_source_title_by_id($post->source_id);
                $main_news_source_url   = source_news_url($post->source_id,$main_news_source);
                $main_news_date_url         = date_news_url($post->publish_time);
                ?>
                <div class="sub-head-link-date">
                    <a href="<?php echo $main_news_source_url;?>"><?php echo $main_news_source;?></a>, 
                    <a href="<?php echo $main_news_date_url;?>"><?php echo translateable_date($post->publish_time);#added on version 1.4?></a>
                </div>
                <div class="clearfix"></div>
            </li>
            <?php 
            }
            ?>
        </ul>
        <?php }?>
    </div>
</div>
<div style="clear:both"></div>
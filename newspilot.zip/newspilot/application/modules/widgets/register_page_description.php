<h4><?php echo lang_key('register_for_new_account');?></h4>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas urna ut enim semper, tempus adipiscing nisi ornare. Vivamus ut rdum urna, at aliquam nulla. Fusce laoreet metus eget nisl varius posuere. Aliquam sapien augue, semper ut magna ut, rutrum malesuada sapien.
                <br />
            <h5>Your data will be save with us</h5>
            Mauris ac dui consectetur, condimentum est ac, tristique velit. Phasellus varius volutpat sem quis semper. Nullam id egestas purus, eget rhoncus erat. Aenean at nullaortis. In semper fermentum nibh, in congue urna sollicitudin eu. Curaagna. Proin egestas lorem vel tincidunt interdum. Integer aliquet varius tellus, eu feugiat justo vestibulum id. Morbi ultrices ultrices . Nullam rutrum sem ante, ut eleifend purus porttitor in.
            <br />
            Mauris ac dui consectetur, condimentum est ac, tristique velit. Phasellus varius volutpat sem quis semper. Nullam id egestas purus, eget rhoncus erat. A diam laoreet lobortis. In semper fermentum nibh, in congue urna sollicitudin eu. Curaagna. Proin egestas lorem vel tincidunt interdum. Integer aliquet varius tellus, eu feugiat justo vestibulum id. Morbi ultrices ultrices . Nullam rutrum sem ante, ut eleifend purus porttitor in.</p>
            <br />
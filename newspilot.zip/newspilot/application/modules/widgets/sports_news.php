<?php 
$source_id    	= 2;
$category 	  	= 'all';
$sub_category 	= 'all';
$limit 			= 20;
$wid_title 		= get_source_title_by_id($source_id);
$more_url 		= source_news_url($source_id,get_source_title_by_id($source_id));

require'pagebody_widget_content.php';
?>
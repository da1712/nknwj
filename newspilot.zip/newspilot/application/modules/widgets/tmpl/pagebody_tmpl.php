<?php 
$source_id    	= #source_id;
$category 	  	= #parent_category;
$sub_category 	= 'all';
$limit 			= #limit;
$wid_title 		= #wid_title;
$more_url 		= #more_url;

require'pagebody_widget_content.php';
?>
<?php 
$source_id    	= 'all';
$category 	  	= 25;
$sub_category 	= 'all';
$limit 			= 15;
$wid_title 		= get_category_title_by_id($category);
$more_url 		= category_news_url($category,get_category_title_by_id($category));

require'pagebody_widget_content.php';
?>
<?php 
$source_id    	= 'all';
$category 	  	= 19;
$sub_category 	= 'all';
$limit 			= 20;
$wid_title 		= get_category_title_by_id($category);
$more_url 		= category_news_url($category,get_category_title_by_id($category));

require'pagebody_widget_content.php';
?>
<?php 
$source_id    = 'all';
$category 	  = 'all';
$sub_category = 'all';
$limit = 5;

if($CI->uri->segment(1)!='news')
{
    echo 'This widget is not for this page';
}
else
{

$CI = get_instance();
$CI->load->model('admin/news_model');

$news_id = $CI->uri->segment(2);
$news = $CI->news_model->get_news_by_id($news_id);
if($news->num_rows()>0)
{
    $row = $news->row();
    $news_query = $CI->news_model->get_similar_news_by_category($row->category, $row->sub_category, $row->id,$limit);
}

?>
<div class="s-widget">
    <!-- Heading -->
    <h5><i class="fa fa-building color"></i>&nbsp; <?php echo lang_key('related_news');?></h5>
    <!-- Widgets Content -->
    <div class="widget-content hot-properties">
        <?php if($news_query->num_rows()<=0){?>
        <div class="alert alert-info"><?php echo lang_key('no_posts');?></div>
        <?php }else{?>
        <ul class="list-unstyled">
            <?php 
            foreach ($news_query->result() as $post) {
            ?>
            <li class="col-xs-12 col-sm-6 col-md-12 col-lg-12">
                <!-- Image -->
                <a href="<?php echo post_detail_url($post);?>">
                <?php if($CI->session->userdata('lazyload')=='yes'){?>
                <img class="img-responsive img-thumbnail lazy-thumb" src="<?php echo base_url('uploads/images/no-image.jpeg');?>" data-src="<?php echo $post->media;?>" alt="<?php echo $post->title;?>" /></a>
                <?php }else{?>
                <img class="img-responsive img-thumbnail" src="<?php echo $post->media;?>" alt="<?php echo $post->title;?>" /></a>
                <?php }?>
                <!-- Heading -->
                <h4><a href="<?php echo post_detail_url($post);?>"><?php echo $post->title;?></a></h4>
                <div class="clearfix"></div>
            </li>
            <?php 
            }
            ?>
        </ul>
        <?php }?>
    </div>
</div>
<div style="clear:both"></div>
<?php
}
?>
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * memeshare Admin Controller
 *
 * This class handles some admin functionality
 *
 * @package		bookit
 * @subpackage	Admin
 * @author		sc mondal
 * @link		http://scmondal.webhelios.com
 */
require_once'Fbauth_core.php';
class Fbauth extends Fbauth_core {

	public function __construct()
	{
		parent::__construct();
	}
}
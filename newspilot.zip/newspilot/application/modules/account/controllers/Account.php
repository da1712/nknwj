<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * memeshare Admin Controller
 *
 * This class handles some admin functionality
 *
 * @package		bookit
 * @subpackage	Admin
 * @author		sc mondal
 * @link		http://scmondal.webhelios.com
 */
require_once'Account_core.php';
class Account extends Account_core {

	public function __construct()
	{
		parent::__construct();
	}

}
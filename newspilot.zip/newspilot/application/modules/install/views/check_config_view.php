<?php

	$error_flag = 0;

	$files = array(	'user_uploads','user_uploads/plugins','user_uploads/plugins/tmp','uploads',
					'uploads/profile_photos','uploads/profile_photos/thumb','uploads/images','uploads/thumbs',
					'dbc_config','application/config/database.php',
					'application/config/config.php', 'dbc_config/config.xml',
					'application/modules/widgets');

	$error = '';



	foreach ($files as $file) 

	{

		if(is_writable($file)==FALSE)

		{

			$error_flag = 1;

			$error .= '<div class="alert alert-danger">SITE_ROOT/'.$file.' is not writable.Please change it\'s permission before installing Whiz[ERROR].</div>';

		}

		else

		{

			$error .= '<div class="alert alert-success">SITE_ROOT/'.$file.' is writable.[OK]</div>';			

		}

	}





	if (extension_loaded('gd') && function_exists('gd_info')) 

	{

		$error .= '<div class="alert alert-success"> GD/GD2 library is installed[OK].</div>';

	}

	else

	{

		$error_flag = 1;

		$error .= '<div class="alert alert-danger">GD library is not installed[ERROR].</div>';		

	}



	if(function_exists('curl_version'))

	{

		$error .= '<div class="alert alert-success">CURL is enabled[OK].</div>';

		//added on version 1.4
		$res = nxs_cURLTest("http://webhelios.com/app/envato/index.php/admin/verify/checkproductkey", "HTTP to Webhelios", "0");
		if($res)
		{
			$error .= '<div class="alert alert-success">CURL calling is ok [OK].</div>';
		}
		else
		{
			$error_flag = 1;

			$error .= '<div class="alert alert-danger">CURL called failed.[ERROR].</div>';			
		}
		//end

	}

	else

	{

		$error_flag = 1;

		$error .= '<div class="alert alert-danger">CURL is not enabled[ERROR].</div>';

	}

	//added on version 1.4
	function nxs_cURLTest($url, $msg, $testText)
	{  
	  $ch = curl_init(); 
	  curl_setopt($ch, CURLOPT_URL, $url); 
	  curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.73 Safari/537.36"); 
	  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
	  curl_setopt($ch, CURLOPT_TIMEOUT, 10); 
	  curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
	  $response = curl_exec($ch); 
	  $errmsg = curl_error($ch); 
	  $cInfo = curl_getinfo($ch); 
	  curl_close($ch); 
	  if (stripos($response, $testText)!==false) 
	    return TRUE; 
	  else 
	  { 
	  	return FALSE;
	  }
	}
	//end


	$wrappers = stream_get_wrappers();

	if(in_array('https',$wrappers))

	{

		$error .= '<div class="alert alert-success">HTTPS wrapper is enabled[OK].</div>';

	}

	else

	{

		$error_flag = 1;

		$error .= '<div class="alert alert-danger">HTTPS wrapper is not enabled[ERROR].</div>';

	}



	if ( function_exists( 'mail' ) )

	{

		$error .= '<div class="alert alert-success">MAIL() function is enabled[OK].</div>';

	}

	else

	{

		//$error_flag = 1;

		$error .= '<div class="alert alert-warning">MAIL() function is not enabled[ERROR].</div>';

	}





	if(function_exists('fsockopen')) 

	{

		$error .= '<div class="alert alert-success">fsockopen() function is enabled[OK].</div>';

	}

	else

	{

		$error .= '<div class="alert alert-warning">fsockopen() function is not enabled[WARNING].</div>';

	}



	echo $error;



	if($error_flag == 0)

	{

		?>

		<p class="lead">Everything seems to be ok. Let's install Whiz with in 2 easy step :-)</p>

		<ol>

			<li>Database setup</li>

			<li>Account setup</li>

		</ol>

		<a class="btn btn-success" href="<?php echo site_url('install/dbsetup');?>">Continue</a> to the next step.</p>

		<?php

	}
	else
	{
		?>
		<div class="alert alert-info">Please fix the error. You'll see the installation button</div>
		<?php
	}

?>


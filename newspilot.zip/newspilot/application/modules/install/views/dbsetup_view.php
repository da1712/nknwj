<form action="<?php echo site_url('install/savedbsettings');?>" method="post">
	<h4>Database setup:</h4>
	<hr/>
	
	<?php echo $this->session->flashdata('msg');?>
	<div class="form-group">
	    <label for="">DB Host</label>
		<input type="text" name="db_host" value="<?php if(set_value('db_host')!='')echo set_value('db_host');else echo 'localhost';?>" placeholder="Db Host" class="form-control" >
		<?php echo form_error('db_host'); ?>
	</div>

	<div class="form-group">
	    <label for="">DB user</label>
		<input type="text" name="db_user" value="<?php if(set_value('db_user')!='')echo set_value('db_user');else echo 'root';?>" placeholder="Db Username" class="form-control" >
		<?php echo form_error('db_user'); ?>
	</div>

	<div class="form-group">
	    <label for="">DB Password</label>
		<input type="text" name="db_pass" value="<?php if(set_value('db_pass')!='')echo set_value('db_pass');else echo '';?>" placeholder="" class="form-control" >
		<?php echo form_error('db_pass'); ?>
	</div>

	<div class="form-group">
	    <label for="">DB Name</label>
		<input type="text" name="db_name" value="<?php if(set_value('db_name')!='')echo set_value('db_name');else echo 'newspilot';?>" placeholder="Db name" class="form-control" >
		<?php echo form_error('db_name'); ?>
	</div>

	<div class="form-group">
	    <label for="">DB Prefix</label>
		<input type="text" name="db_prefix" value="<?php if(set_value('db_prefix')!='')echo set_value('db_prefix');else echo 'np_';?>" placeholder="Db tableprefix" class="form-control" >
		<?php echo form_error('db_prefix'); ?>
	</div>

    <div style="clear:both;"></div> 
	<button type="submit" class="btn btn-success">Save & Next</button>
</form>
<img src="<?php echo base_url('assets/admin/icons');?>/complete.png" style="width:100px;" />
<p class="lead">Setup is complete :D</p>
<a href="<?php echo site_url();?>" class="btn btn-success">Visit Site</a>
<a href="<?php echo site_url('admin');?>" class="btn btn-info">Admin Panel</a>
<div style="clear:both;margin-top:20px"></div>
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Classified admin Controller
 *
 * This class handles user account related functionality
 *
 * @package		Show
 * @subpackage	Show
 * @author		webhelios
 * @link		http://webhelios.com
 */
require_once 'Grab_core.php';
class Grab extends Grab_core {

	public function __construct()
	{
		parent::__construct();
	}
}
/* End of file install.php */
/* Location: ./application/modules/show/controllers/show.php */
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Classified blog_model model
 *
 * This class handles blog_model management related functionality
 *
 * @package		Admin
 * @subpackage	blog_model
 * @author		webhelios
 * @link		http://webhelios.com
 */

require_once'News_model_core.php';

class News_model extends News_model_core 
{
	function __construct()
	{
		parent::__construct();
	}

}

/* End of file blog_model.php */
/* Location: ./system/application/models/blog_model.php */
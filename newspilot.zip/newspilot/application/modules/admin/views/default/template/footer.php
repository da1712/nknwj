<footer>
<p>
   <?php echo translate(get_settings('site_settings','footer_text','copyright@'));?> | Powered by <a href="http://codecanyon.net/user/webhelios/portfolio?ref=webhelios">Webhelios</a>
</p>
</footer>
<a id="btn-scrollup" class="btn btn-circle btn-lg" href="index.html#"><i class="fa fa-chevron-up"></i></a>
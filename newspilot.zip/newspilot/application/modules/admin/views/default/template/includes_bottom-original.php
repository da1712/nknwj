<script src="<?php echo base_url();?>assets/admin/assets/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assets/admin/assets/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<script src="<?php echo base_url();?>assets/admin/assets/jquery-cookie/jquery.cookie.js"></script>

<!--Tables-->
<!--script src="<?php echo base_url();?>assets/admin/assets/data-tables/jquery.dataTables.js"></script>
<script src="<?php echo base_url();?>assets/admin/assets/data-tables/bootstrap3/dataTables.bootstrap.js"></script-->

<!--Chart-->
<!--script src="<?php echo base_url();?>assets/admin/assets/flot/jquery.flot.js"></script>
<script src="<?php echo base_url();?>assets/admin/assets/flot/jquery.flot.resize.js"></script>
<script src="<?php echo base_url();?>assets/admin/assets/flot/jquery.flot.pie.js"></script>
<script src="<?php echo base_url();?>assets/admin/assets/flot/jquery.flot.stack.js"></script>
<script src="<?php echo base_url();?>assets/admin/assets/flot/jquery.flot.crosshair.js"></script>
<script src="<?php echo base_url();?>assets/admin/assets/flot/jquery.flot.tooltip.min.js"></script>
<script src="<?php echo base_url();?>assets/admin/assets/sparkline/jquery.sparkline.min.js"></script-->


<!--Calendar-->
<script src="<?php echo base_url();?>assets/admin/assets/jquery-ui/jquery-ui.min.js"></script>
<!--script src="<?php echo base_url();?>assets/admin/assets/fullcalendar/fullcalendar/fullcalendar.min.js"></script-->

<!--Slider knob-->
<!--script src="<?php echo base_url();?>assets/admin/assets/jquery-knob/jquery.knob.js"></script-->

<!--Rich text editor-->
<!--script src="<?php echo base_url();?>assets/admin/assets/bootstrap-wysihtml5/wysihtml5-0.3.0.js"></script> 
<script src="<?php echo base_url();?>assets/admin/assets/bootstrap-wysihtml5/bootstrap-wysihtml5.js"></script-->

<!--Form Component-->
<!--script src="<?php echo base_url();?>assets/admin/assets/chosen-bootstrap/chosen.jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/admin/assets/bootstrap-inputmask/bootstrap-inputmask.min.js"></script>
<script src="<?php echo base_url();?>assets/admin/assets/jquery-tags-input/jquery.tagsinput.min.js"></script>
<script src="<?php echo base_url();?>assets/admin/assets/jquery-pwstrength/jquery.pwstrength.min.js"></script>
<script src="<?php echo base_url();?>assets/admin/assets/bootstrap-fileupload/bootstrap-fileupload.min.js"></script>
<script src="<?php echo base_url();?>assets/admin/assets/bootstrap-duallistbox/duallistbox/bootstrap-duallistbox.js"></script>
<script src="<?php echo base_url();?>assets/admin/assets/dropzone/downloads/dropzone.min.js"></script>
<script src="<?php echo base_url();?>assets/admin/assets/bootstrap-timepicker/js/bootstrap-timepicker.js"></script>
<script src="<?php echo base_url();?>assets/admin/assets/clockface/js/clockface.js"></script>
<script src="<?php echo base_url();?>assets/admin/assets/bootstrap-colorpicker/js/bootstrap-colorpicker.js"></script>
<script src="<?php echo base_url();?>assets/admin/assets/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
<script src="<?php echo base_url();?>assets/admin/assets/bootstrap-daterangepicker/date.js"></script>
<script src="<?php echo base_url();?>assets/admin/assets/bootstrap-daterangepicker/daterangepicker.js"></script>
<script src="<?php echo base_url();?>assets/admin/assets/bootstrap-switch/static/js/bootstrap-switch.js"></script-->
<script src="<?php echo base_url();?>assets/admin/assets/ckeditor/ckeditor.js"></script> 

<!--Form Validation, Wizard-->
<!--script src="<?php echo base_url();?>assets/admin/assets/jquery-validation/dist/jquery.validate.min.js"></script>
<script src="<?php echo base_url();?>assets/admin/assets/jquery-validation/dist/additional-methods.min.js"></script>
<script src="<?php echo base_url();?>assets/admin/assets/bootstrap-wizard/jquery.bootstrap.wizard.js"></script-->

<!--Gallery-->
<!--script src="<?php echo base_url();?>assets/admin/assets/prettyPhoto/js/jquery.prettyPhoto.js"></script-->

<!--Google Map [ Load gmap plugins only in gmap page ]
<script src="http://maps.google.com/maps/api/js?sensor=true"></script>
<script src="<?php echo base_url();?>assets/admin/assets/gmaps/gmaps.js"></script>
<script src="<?php echo base_url();?>assets/admin/assets/gmaps/gmap_custom.js"></script>-->

<!--Vector Map [ Load gmap plugins only in gmap page ]
<script src="<?php echo base_url();?>assets/admin/assets/jqvmap/jqvmap/jquery.vmap.min.js"></script>
<script src="<?php echo base_url();?>assets/admin/assets/jqvmap/jqvmap/maps/jquery.vmap.world.js"></script>
<script src="<?php echo base_url();?>assets/admin/assets/jqvmap/jqvmap/maps/jquery.vmap.usa.js"></script>
<script src="<?php echo base_url();?>assets/admin/assets/jqvmap/jqvmap/maps/jquery.vmap.germany.js"></script>
<script src="<?php echo base_url();?>assets/admin/assets/jqvmap/jqvmap/maps/jquery.vmap.europe.js"></script>
<script src="<?php echo base_url();?>assets/admin/assets/jqvmap/jqvmap/data/jquery.vmap.sampledata.js"></script>
<script src="<?php echo base_url();?>assets/admin/assets/jqvmap/jqvmap/data/jqvmap_custom.js"></script>-->

<!--Gritter-->
<!--script src="<?php echo base_url();?>assets/admin/assets/gritter/js/jquery.gritter.js"></script-->

<!--Digital clock-->
<!--script src="<?php echo base_url();?>assets/admin/assets/clock-digital/moment.min.js"></script>
<script src="<?php echo base_url();?>assets/admin/assets/clock-digital/clock.js"></script-->
        
<!--Template Scripting-->
<script src="<?php echo base_url();?>assets/admin/js/webhelios.js"></script>
<script src="<?php echo base_url();?>assets/admin/js/webhelios-demo-codes.js"></script>


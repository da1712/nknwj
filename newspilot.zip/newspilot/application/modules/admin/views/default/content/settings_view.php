<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/admin/assets/bootstrap-colorpicker/css/colorpicker.css" />
<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-title">
                <h3><i class="fa fa-bars"></i><?php echo lang_key_admin("site_settings") ?> </h3>

                <div class="box-tool">
                    <a href="#" data-action="collapse"><i class="fa fa-chevron-up"></i></a>
                </div>
            </div>
            <div class="box-content">
                <?php echo $this->session->flashdata('msg'); ?>
                <?php echo validation_errors();?>
                <?php $settings = json_decode($settings);?>
                <form class="form-horizontal" action="<?php echo site_url('admin/content/savesettings/');?>" method="post">
                    


                    <div class="form-group">
                        <label class="col-sm-3 col-lg-2 control-label"><?php echo lang_key_admin('enable_signup'); ?></label>

                        <div class="col-sm-9 col-md-3 controls">
                            <select name="enable_signup" class="form-control">
                                <?php $options = array('Yes','No');?>
                                <?php foreach($options as $row){?>
                                    <?php $sel=($settings->enable_signup==$row)?'selected="selected"':'';?>
                                    <option value="<?php echo $row;?>" <?php echo $sel;?>><?php echo $row;?></option>
                                <?php }?>
                            </select>
                            <input type="hidden" name="enable_signup_rules" value="required">
                            <span class="help-inline">&nbsp;</span>
                            <?php echo form_error('enable_signup'); ?>
                        </div>
                    </div>


                    <div class="form-group">
                        <label class="col-sm-3 col-lg-2 control-label"><?php echo lang_key_admin('moderator_can_create_post'); ?></label>

                        <div class="col-sm-9 col-md-3 controls">
                            <select name="moderator_can_create_post" class="form-control">
                                <?php $options = array('Yes','No');?>
                                <?php foreach($options as $row){?>
                                    <?php $sel=($settings->moderator_can_create_post==$row)?'selected="selected"':'';?>
                                    <option value="<?php echo $row;?>" <?php echo $sel;?>><?php echo $row;?></option>
                                <?php }?>
                            </select>
                            <input type="hidden" name="moderator_can_create_post_rules" value="required">
                            <span class="help-inline">&nbsp;</span>
                            <?php echo form_error('moderator_can_create_post'); ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-3 col-lg-2 control-label"><?php echo lang_key_admin('generaluser_can_create_post'); ?></label>

                        <div class="col-sm-9 col-md-3 controls">
                            <select name="generaluser_can_create_post" class="form-control">
                                <?php $options = array('No','Yes');?>
                                <?php foreach($options as $row){?>
                                    <?php $sel=($settings->generaluser_can_create_post==$row)?'selected="selected"':'';?>
                                    <option value="<?php echo $row;?>" <?php echo $sel;?>><?php echo $row;?></option>
                                <?php }?>
                            </select>
                            <input type="hidden" name="generaluser_can_create_post_rules" value="required">
                            <span class="help-inline">&nbsp;</span>
                            <?php echo form_error('generaluser_can_create_post'); ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-3 col-lg-2 control-label"><?php echo lang_key_admin('publish_posts_directly'); ?></label>

                        <div class="col-sm-9 col-md-3 controls">
                            <select name="publish_directly" class="form-control">
                                <?php $options = array('No','Yes');?>
                                <?php foreach($options as $row){?>
                                    <?php $sel=($settings->publish_directly==$row)?'selected="selected"':'';?>
                                    <option value="<?php echo $row;?>" <?php echo $sel;?>><?php echo $row;?></option>
                                <?php }?>
                            </select>
                            <input type="hidden" name="publish_directly_rules" value="required">
                            <span class="help-inline">&nbsp;</span>
                            <?php echo form_error('publish_directly'); ?>
                        </div>
                    </div>


                    <div class="form-group">
                        <label class="col-sm-3 col-lg-2 control-label"><?php echo lang_key_admin('auto_crawl'); ?></label>

                        <div class="col-sm-9 col-md-3 controls">
                            <select name="auto_crawl" class="form-control">
                                <?php $options = array('Yes','No');?>
                                <?php foreach($options as $row){?>
                                    <?php $sel=($settings->auto_crawl==$row)?'selected="selected"':'';?>
                                    <option value="<?php echo $row;?>" <?php echo $sel;?>><?php echo $row;?></option>
                                <?php }?>
                            </select>
                            <input type="hidden" name="auto_crawl_rules" value="required">
                            <span class="help-inline">&nbsp;</span>
                            <?php echo form_error('auto_crawl'); ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-3 col-lg-2 control-label"><?php echo lang_key_admin('disable_main_site_link'); ?></label>

                        <div class="col-sm-9 col-md-3 controls">
                            <select name="disable_main_site_link" class="form-control">
                                <?php $options = array('No','Yes');?>
                                <?php foreach($options as $row){?>
                                    <?php $sel=($settings->disable_main_site_link==$row)?'selected="selected"':'';?>
                                    <option value="<?php echo $row;?>" <?php echo $sel;?>><?php echo $row;?></option>
                                <?php }?>
                            </select>
                            <input type="hidden" name="disable_main_site_link_rules" value="required">
                            <span class="help-inline">&nbsp;</span>
                            <?php echo form_error('disable_main_site_link'); ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-3 col-lg-2 control-label"><?php echo lang_key_admin('save_images_locally'); ?></label>

                        <div class="col-sm-9 col-md-3 controls">
                            <select name="save_images_locally" class="form-control">
                                <?php $options = array('Yes','No');?>
                                <?php foreach($options as $row){?>
                                    <?php $sel=($settings->save_images_locally==$row)?'selected="selected"':'';?>
                                    <option value="<?php echo $row;?>" <?php echo $sel;?>><?php echo $row;?></option>
                                <?php }?>
                            </select>
                            <input type="hidden" name="save_images_locally_rules" value="required">
                            <span class="help-inline">&nbsp;</span>
                            <?php echo form_error('save_images_locally'); ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-3 col-lg-2 control-label"><?php echo lang_key_admin('lazy_load_images'); ?></label>

                        <div class="col-sm-9 col-md-3 controls">
                            <select name="lazy_load_images" class="form-control">
                                <?php $options = array('Yes','No');?>
                                <?php foreach($options as $row){?>
                                    <?php $sel=($settings->lazy_load_images==$row)?'selected="selected"':'';?>
                                    <option value="<?php echo $row;?>" <?php echo $sel;?>><?php echo $row;?></option>
                                <?php }?>
                            </select>
                            <input type="hidden" name="lazy_load_images_rules" value="required">
                            <span class="help-inline">&nbsp;</span>
                            <?php echo form_error('lazy_load_images'); ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-3 col-lg-2 control-label"><?php echo lang_key_admin('show_marquee'); ?></label>

                        <div class="col-sm-9 col-md-3 controls">
                            <select name="show_marquee" class="form-control">
                                <?php $options = array('Yes','No');?>
                                <?php foreach($options as $row){?>
                                    <?php $sel=($settings->show_marquee==$row)?'selected="selected"':'';?>
                                    <option value="<?php echo $row;?>" <?php echo $sel;?>><?php echo $row;?></option>
                                <?php }?>
                            </select>
                            <input type="hidden" name="show_marquee_rules" value="required">
                            <span class="help-inline">&nbsp;</span>
                            <?php echo form_error('show_marquee'); ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-3 col-lg-2 control-label"><?php echo lang_key_admin('enable_cache'); ?></label>

                        <div class="col-sm-9 col-md-3 controls">
                            <select name="enable_cache" class="form-control">
                                <?php $options = array('No','Yes');?>
                                <?php foreach($options as $row){?>
                                    <?php $sel=($settings->enable_cache==$row)?'selected="selected"':'';?>
                                    <option value="<?php echo $row;?>" <?php echo $sel;?>><?php echo $row;?></option>
                                <?php }?>
                            </select>
                            <input type="hidden" name="enable_cache_rules" value="required">
                            <span class="help-inline">&nbsp;</span>
                            <?php echo form_error('enable_cache'); ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-3 col-lg-2 control-label"><?php echo lang_key_admin('enable_cookie_policy_popup'); ?></label>

                        <div class="col-sm-9 col-md-3 controls">
                            <select name="enable_cookie_policy_popup" class="form-control">
                                <?php $options = array('Yes','No');?>
                                <?php foreach($options as $row){?>
                                    <?php $sel=($settings->enable_cookie_policy_popup==$row)?'selected="selected"':'';?>
                                    <option value="<?php echo $row;?>" <?php echo $sel;?>><?php echo $row;?></option>
                                <?php }?>
                            </select>
                            <input type="hidden" name="enable_cookie_policy_popup_rules" value="required">
                            <span class="help-inline">&nbsp;</span>
                            <?php echo form_error('enable_cookie_policy_popup'); ?>
                        </div>
                    </div>



                    <div class="form-group cookie-policy-settings" id="cookie_policy_page_url" style="display:none">
                        <label class="col-sm-3 col-lg-2 control-label"><?php echo lang_key_admin('cookie_policy_page_url'); ?></label>

                        <div class="col-sm-9 col-lg-10 controls">
                            <input type="text" name="cookie_policy_page_url" value="<?php echo(isset($settings->cookie_policy_page_url))?$settings->cookie_policy_page_url:'';?>" placeholder="<?php echo lang_key_admin('type_something');?>" class="form-control" >
                            <input type="hidden" name="cookie_policy_page_url_rules" value="required">
                            <span class="help-inline">&nbsp;</span>
                            <?php echo form_error('cookie_policy_page_url'); ?>
                        </div>
                    </div>
                   
                    <!-- added on version 1.3 -->
                    <div class="form-group">
                        <label class="col-sm-3 col-lg-2 control-label"><?php echo lang_key_admin('five_filters_api_url'); ?></label>

                        <div class="col-sm-9 col-lg-10 controls">
                            <input type="text" name="five_filters_api_url" value="<?php echo(isset($settings->five_filters_api_url))?$settings->five_filters_api_url:'';?>" placeholder="<?php echo lang_key_admin('type_something');?>" class="form-control" >
                            <input type="hidden" name="five_filters_api_url_rules" value="required">
                            <span class="help-inline">&nbsp;</span>
                            <?php echo form_error('five_filters_api_url'); ?>
                        </div>
                    </div>
                    <!-- end -->

                    <!-- added on version 1.4 -->
                    <div class="form-group">
                        <label class="col-sm-3 col-lg-2 control-label"><?php echo lang_key_admin('show_source_menu'); ?></label>

                        <div class="col-sm-9 col-md-3 controls">
                            <select name="show_source_menu" class="form-control">
                                <?php $options = array('Yes','No');?>
                                <?php foreach($options as $row){?>
                                    <?php $sel=($settings->show_source_menu==$row)?'selected="selected"':'';?>
                                    <option value="<?php echo $row;?>" <?php echo $sel;?>><?php echo $row;?></option>
                                <?php }?>
                            </select>
                            <input type="hidden" name="show_source_menu_rules" value="required">
                            <span class="help-inline">&nbsp;</span>
                            <?php echo form_error('show_source_menu'); ?>
                        </div>
                    </div>


                    <div class="form-group">
                        <label class="col-sm-3 col-lg-2 control-label"><?php echo lang_key_admin('show_cat_menu'); ?></label>

                        <div class="col-sm-9 col-md-3 controls">
                            <select name="show_cat_menu" class="form-control">
                                <?php $options = array('Yes','No');?>
                                <?php foreach($options as $row){?>
                                    <?php $sel=($settings->show_cat_menu==$row)?'selected="selected"':'';?>
                                    <option value="<?php echo $row;?>" <?php echo $sel;?>><?php echo $row;?></option>
                                <?php }?>
                            </select>
                            <input type="hidden" name="show_cat_menu_rules" value="required">
                            <span class="help-inline">&nbsp;</span>
                            <?php echo form_error('show_cat_menu'); ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-3 col-lg-2 control-label"><?php echo lang_key_admin('enable_adblocker_alert'); ?></label>

                        <div class="col-sm-9 col-md-3 controls">
                            <select name="enable_adblocker_alert" class="form-control">
                                <?php $options = array('No','Yes');?>
                                <?php foreach($options as $row){?>
                                    <?php $sel=($settings->enable_adblocker_alert==$row)?'selected="selected"':'';?>
                                    <option value="<?php echo $row;?>" <?php echo $sel;?>><?php echo $row;?></option>
                                <?php }?>
                            </select>
                            <input type="hidden" name="enable_adblocker_alert_rules" value="required">
                            <span class="help-inline">&nbsp;</span>
                            <?php echo form_error('enable_adblocker_alert'); ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-3 col-lg-2 control-label"><?php echo lang_key_admin('enable_featured_news_carousel'); ?></label>

                        <div class="col-sm-9 col-md-3 controls">
                            <select name="enable_featured_news_carousel" class="form-control">
                                <?php $options = array('None','Carousel','Slider');?>
                                <?php foreach($options as $row){?>
                                    <?php $sel=($settings->enable_featured_news_carousel==$row)?'selected="selected"':'';?>
                                    <option value="<?php echo $row;?>" <?php echo $sel;?>><?php echo $row;?></option>
                                <?php }?>
                            </select>
                            <input type="hidden" name="enable_featured_news_carousel_rules" value="required">
                            <span class="help-inline">&nbsp;</span>
                            <?php echo form_error('enable_featured_news_carousel'); ?>
                        </div>
                    </div>

                    <!-- added on version 1.8 -->
                    <div class="form-group">
                        <label class="col-sm-3 col-lg-2 control-label"><?php echo lang_key_admin('use_popular_news'); ?></label>

                        <div class="col-sm-9 col-md-3 controls">
                            <select name="use_popular_news" class="form-control">
                                <?php $options = array('no','yes');?>
                                <?php foreach($options as $row){?>
                                    <?php $sel=($settings->use_popular_news==$row)?'selected="selected"':'';?>
                                    <option value="<?php echo $row;?>" <?php echo $sel;?>><?php echo lang_key_admin($row);?></option>
                                <?php }?>
                            </select>
                            <input type="hidden" name="use_popular_news_rules" value="required">
                            <span class="help-inline">&nbsp;</span>
                            <?php echo form_error('use_popular_news'); ?>
                        </div>
                    </div>
                    <!-- end -->
                    <!-- added on version 1.5 -->
                    <div class="form-group">
                        <label class="col-sm-3 col-lg-2 control-label"><?php echo lang_key_admin('menu_type'); ?></label>

                        <div class="col-sm-9 col-md-3 controls">
                            <select name="menu_type" class="form-control">
                                <?php $options = array('Normal','Mega Menu');?>
                                <?php foreach($options as $row){?>
                                    <?php $sel=($settings->menu_type==$row)?'selected="selected"':'';?>
                                    <option value="<?php echo $row;?>" <?php echo $sel;?>><?php echo $row;?></option>
                                <?php }?>
                            </select>
                            <input type="hidden" name="menu_type_rules" value="required">
                            <span class="help-inline">&nbsp;</span>
                            <?php echo form_error('menu_type'); ?>
                        </div>
                    </div>
                    <!-- end -->

                    <!-- added on version 1.7 -->
                    <div class="form-group">
                        <label class="col-sm-3 col-lg-2 control-label"><?php echo lang_key_admin('spintax_support'); ?></label>

                        <div class="col-sm-9 col-md-3 controls">
                            <select name="spintax_support" class="form-control">
                                <?php $options = array('no','yes');?>
                                <?php foreach($options as $row){?>
                                    <?php $sel=($settings->spintax_support==$row)?'selected="selected"':'';?>
                                    <option value="<?php echo $row;?>" <?php echo $sel;?>><?php echo lang_key($row);?></option>
                                <?php }?>
                            </select>
                            <input type="hidden" name="spintax_support_rules" value="required">
                            <span class="help-inline">&nbsp;</span>
                            <?php echo form_error('spintax_support'); ?>
                        </div>
                    </div>
                    <!-- end -->


                  <div class="form-group">
                    <label class="col-sm-3 col-lg-2 control-label"><?php echo lang_key('body_color');?>:</label>
                      <div class="col-sm-5 col-lg-3 controls">
                          <?php $v = (set_value('body_color')!='')?set_value('body_color'):get_settings('global_settings','body_color', '#ECF0F1');?>
                          <div class="input-group color colorpicker-default" data-color="<?php echo $v;?>" data-color-format="rgba">
                            <span class="input-group-addon"><i style="background-color: <?php echo $v;?>;"></i></span>
                            <input type="text" name="body_color" class="form-control" value="<?php echo $v;?>">
                          </div>
                      </div>
                  </div>


                    <div style="border-bottom:1px solid #aaa;font-weight:bold;font-size:14px;padding:0 0 5px 5px;"><?php echo lang_key_admin('facebook_app_settings');?></div>

                    <div class="form-group">
                        <label class="col-sm-3 col-lg-2 control-label"><?php echo lang_key_admin('enable_facebook_login'); ?></label>
                        <div class="col-sm-9 col-md-3 controls">
                            <select name="enable_fb_login" class="form-control">
                                <?php $options = array('Yes','No');?>
                                <?php foreach($options as $row){?>
                                    <?php $sel=($settings->enable_fb_login==$row)?'selected="selected"':'';?>
                                    <option value="<?php echo $row;?>" <?php echo $sel;?>><?php echo $row;?></option>
                                <?php }?>
                            </select>
                            <input type="hidden" name="enable_fb_login_rules" value="required">
                            <span class="help-inline">&nbsp;</span>
                            <?php echo form_error('enable_fb_login'); ?>
                        </div>
                    </div>

                    <div class="form-group fb-settings" id="fb_app_id" style="display:none">
                        <label class="col-sm-3 col-lg-2 control-label"><?php echo lang_key_admin('fb_app_id'); ?></label>

                        <div class="col-sm-9 col-lg-10 controls">
                            <input type="text" name="fb_app_id" value="<?php echo(isset($settings->fb_app_id))?$settings->fb_app_id:'';?>" placeholder="<?php echo lang_key_admin('type_something');?>" class="form-control" >
                            <input type="hidden" name="fb_app_id_rules" value="required">
                            <span class="help-inline">&nbsp;</span>
                            <?php echo form_error('fb_app_id'); ?>
                        </div>
                    </div>

                    <div class="form-group fb-settings" id="fb_secret_key" style="display:none">
                        <label class="col-sm-3 col-lg-2 control-label"><?php echo lang_key_admin('fb_secret_key'); ?></label>

                        <div class="col-sm-9 col-lg-10 controls">
                            <input type="text" name="fb_secret_key" value="<?php echo(isset($settings->fb_secret_key))?$settings->fb_secret_key:'';?>" placeholder="<?php echo lang_key_admin('type_something');?>" class="form-control" >
                            <input type="hidden" name="fb_secret_key_rules" value="required">
                            <span class="help-inline">&nbsp;</span>
                            <?php echo form_error('fb_secret_key'); ?>
                        </div>
                    </div>


                    <!--start-->



                    <div style="border-bottom:1px solid #aaa;font-weight:bold;font-size:14px;padding:0 0 5px 5px;"><?php echo lang_key_admin('comment_settings');?></div>

                    <div class="form-group">
                        <label class="col-sm-3 col-lg-2 control-label"><?php echo lang_key_admin('enable_comment'); ?></label>
                        <div class="col-sm-9 col-md-3 controls">
                            <select name="enable_comment" class="form-control">
                                <?php $options = array('No','Facebook Comment', 'Disqus Comment');?>
                                <?php foreach($options as $row){?>
                                    <?php $v = (set_value('enable_comment')!='')?set_value('enable_comment'):$settings->enable_comment;?>
                                    <?php $sel=($v==$row)?'selected="selected"':'';?>
                                    <option value="<?php echo $row;?>" <?php echo $sel;?>><?php echo $row;?></option>
                                <?php }?>
                            </select>
                            <input type="hidden" name="enable_comment_rules" value="required">
                            <span class="help-inline">&nbsp;</span>
                            <?php echo form_error('enable_comment'); ?>
                        </div>
                    </div>

                    <div class="form-group fb-comment-settings" id="fb_app_id" style="display:none">
                        <label class="col-sm-3 col-lg-2 control-label"><?php echo lang_key_admin('fb_app_id'); ?></label>

                        <div class="col-sm-9 col-lg-10 controls">
                            <input type="text" name="fb_comment_app_id" value="<?php echo(isset($settings->fb_comment_app_id))?$settings->fb_comment_app_id:'';?>" placeholder="<?php echo lang_key_admin('type_something');?>" class="form-control" >
                            <input type="hidden" name="fb_comment_app_id_rules" value="required">
                            <span class="help-inline">&nbsp;</span>
                            <?php echo form_error('fb_comment_app_id'); ?>
                        </div>
                    </div>

                    <div class="form-group fb-comment-settings" id="disqus_shortname_holder" style="display:none">
                        <label class="col-sm-3 col-lg-2 control-label"><?php echo lang_key_admin('disqus_shortname'); ?></label>

                        <div class="col-sm-9 col-lg-10 controls">
                            <input type="text" name="disqus_shortname" value="<?php echo(isset($settings->disqus_shortname))?$settings->disqus_shortname:'';?>" placeholder="<?php echo lang_key_admin('type_something');?>" class="form-control" >
                            <input type="hidden" name="disqus_shortname_rules" value="required">
                            <span class="help-inline">&nbsp;</span>
                            <?php echo form_error('disqus_shortname'); ?>
                        </div>
                    </div>


                    <div class="form-group">
                        <label class="col-sm-3 col-lg-2 control-label"></label>

                        <div class="col-sm-9 col-lg-10 controls">
                            <button class="btn btn-primary" type="submit"><i
                                    class="fa fa-check"></i><?php echo lang_key_admin("update") ?></button>
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-title">
                <h3><i class="fa fa-bars"></i><?php echo lang_key_admin("texts_to_filter_out") ?> </h3>

                <div class="box-tool">
                    <a href="#" data-action="collapse"><i class="fa fa-chevron-up"></i></a>
                </div>
            </div>
            <div class="box-content">
                <?php echo $this->session->flashdata('msg'); ?>
                <form class="form-horizontal" action="<?php echo site_url('admin/content/updatefiltertext/');?>" method="post">
                    
                    <div class="form-group" id="">
                        <label class="col-sm-3 col-lg-2 control-label"><?php echo lang_key_admin('filter_text_list'); ?></label>

                        <div class="col-sm-9 col-lg-10 controls">
                            <?php $filter_text_list = get_single_option('filter_text_list');?>
                            <textarea name="filter_text_list" class="form-control"><?php echo $filter_text_list;?></textarea>
                            <input type="hidden" name="filter_text_list_rules" value="required">
                            <span class="help-inline"><?php echo lang_key_admin('filter_text_instruction')?></span>
                            <?php echo form_error('filter_text_list'); ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-3 col-lg-2 control-label"></label>

                        <div class="col-sm-9 col-lg-10 controls">
                            <button class="btn btn-primary" type="submit"><i
                                    class="fa fa-check"></i><?php echo lang_key_admin("update") ?></button>
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-title">
                <h3><i class="fa fa-bars"></i><?php echo lang_key_admin("media_url_update") ?> </h3>

                <div class="box-tool">
                    <a href="#" data-action="collapse"><i class="fa fa-chevron-up"></i></a>
                </div>
            </div>
            <div class="box-content">
                <?php echo $this->session->flashdata('msg'); ?>
                <form class="form-horizontal" action="<?php echo site_url('admin/content/updateoldmedia/');?>" method="post">
                    
                    <div class="form-group" id="">
                        <label class="col-sm-3 col-lg-2 control-label"><?php echo lang_key_admin('old_base_url'); ?></label>

                        <div class="col-sm-9 col-lg-10 controls">
                            <input type="text" name="old_base_url" value="<?php echo(isset($settings->old_base_url))?$settings->old_base_url:'';?>" placeholder="<?php echo lang_key_admin('type_something');?>" class="form-control" >
                            <input type="hidden" name="old_base_url_rules" value="required">
                            <span class="help-inline">&nbsp;</span>
                            <?php echo form_error('old_base_url'); ?>
                        </div>
                    </div>

                    <div class="form-group" id="">
                        <label class="col-sm-3 col-lg-2 control-label"><?php echo lang_key_admin('new_base_url'); ?></label>

                        <div class="col-sm-9 col-lg-10 controls">
                            <input type="text" name="new_base_url" value="<?php echo base_url();?>" placeholder="<?php echo lang_key_admin('type_something');?>" class="form-control" >
                            <input type="hidden" name="new_base_url_rules" value="required">
                            <span class="help-inline">&nbsp;</span>
                            <?php echo form_error('new_base_url'); ?>
                        </div>
                    </div>
                    


                    <div class="form-group">
                        <label class="col-sm-3 col-lg-2 control-label"></label>

                        <div class="col-sm-9 col-lg-10 controls">
                            <button class="btn btn-primary" type="submit"><i
                                    class="fa fa-check"></i><?php echo lang_key_admin("update") ?></button>
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
jQuery(document).ready(function(){
    

    
    
    jQuery('select[name=enable_fb_login]').change(function(e){
        var val = jQuery(this).val();
        if(val=='Yes')
        {
            jQuery('input[name=fb_app_id_rules]').attr('value','required');
            jQuery('input[name=fb_secret_key_rules]').attr('value','required');
            jQuery('.fb-settings').show();
        }
        else
        {
            jQuery('input[name=fb_app_id_rules]').attr('value','');
            jQuery('input[name=fb_secret_key_rules]').attr('value','');
            jQuery('.fb-settings').hide();
        }
    }).change();

    /* start facebook comment settings */

    jQuery('select[name=enable_comment]').change(function(e){
        var val = jQuery(this).val();
        if(val=='Facebook Comment')
        {
            jQuery('input[name=fb_comment_app_id_rules]').attr('value','required');
            jQuery('.fb-comment-settings').show();
        }
        else
        {
            jQuery('input[name=fb_comment_app_id_rules]').attr('value','');
            jQuery('.fb-comment-settings').hide();
        }

        if(val=='Disqus Comment')
        {
            jQuery('input[name=disqus_shortname_rules]').attr('value','required');
            jQuery('#disqus_shortname_holder').show();
        }
        else
        {
            jQuery('input[name=disqus_shortname_rules]').attr('value','');
            jQuery('#disqus_shortname_holder').hide();
        }
    }).change();

    /* end facebook comment settings*/

    jQuery('select[name=enable_gplus_login]').change(function(e){
        var val = jQuery(this).val();
        if(val=='Yes')
        {
            jQuery('input[name=gplus_app_id_rules]').attr('value','required');
            jQuery('input[name=gplus_secret_key_rules]').attr('value','required');
            jQuery('.gplus-settings').show();
        }
        else
        {
            jQuery('input[name=gplus_app_id_rules]').attr('value','');
            jQuery('input[name=gplus_secret_key_rules]').attr('value','');
            jQuery('.gplus-settings').hide();
        }
    }).change();

    jQuery('select[name=enable_cookie_policy_popup]').change(function(e){
        var val = jQuery(this).val();
        if(val=='Yes')
        {
            jQuery('input[name=cookie_policy_page_url_rules]').attr('value','required');
            jQuery('.cookie-policy-settings').show();
        }
        else
        {
            jQuery('input[name=cookie_policy_page_url_rules]').attr('value','');
            jQuery('.cookie-policy-settings').hide();
        }
    }).change();
});
</script>
<script src="<?php echo base_url();?>assets/admin/assets/bootstrap-colorpicker/js/bootstrap-colorpicker.js"></script>
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * content webhelios Controller
 *
 * This class handles webhelios management related functionality
 *
 * @package		Admin
 * @subpackage	webhelios
 * @author		webhelios
 * @link		http://webhelios.com
 */
require_once'Content_core.php';
class Content extends Content_core {

	public function __construct()
	{
		parent::__construct();
	}
}
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Classified admin Controller
 *
 * This class handles admin management related functionality
 *
 * @package		Admin
 * @subpackage	Admin
 * @author		webhelios
 * @link		http://webhelios.com
 */
require_once'Admin_core.php';
class Admin extends Admin_core {

	public function __construct()
	{
		parent::__construct();
	}
}
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Classified system Controller
 *
 * This class handles system management related functionality
 *
 * @package		Admin
 * @subpackage	system
 * @author		webhelios
 * @link		http://webhelios.com
 */
require_once'System_core.php';
class System extends System_core {

	public function __construct()
	{
		parent::__construct();
	}
}
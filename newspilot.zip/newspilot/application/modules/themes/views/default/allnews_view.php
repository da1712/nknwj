<!-- updated on version 1.4 -->
<div class="page-heading-two">
    <div class="container">
        <h2>
        <?php if(isset($icon) && $icon!=''){?>
        <i class="fa <?php echo $icon;?>"></i>&nbsp;
        <?php }?>
        <?php echo (isset($title))?$title:'';?> <span>&nbsp;</span>
        <?php 
        $feed_url = '';
        if(isset($category_id) && $category_id!='')
            $feed_url = site_url('show/feed/category/'.$category_id);
        if(isset($source_id) && $source_id!='')
            $feed_url = site_url('show/feed/source/'.$source_id);
        if(isset($publish_time) && $publish_time!='')
            $feed_url = site_url('show/feed/date/'.$publish_time);

        ?>
        <a href="<?php echo $feed_url;?>"><i class="fa fa-rss"></i></a>
        </h2>        
        <div class="clearfix"></div>
    </div>
</div>
<!-- end -->    
<!-- Container -->
<div class="container">
    <div class="blog-one">
        <div class="row">

            <div class="col-md-9 col-sm-12 col-xs-12">

                <?php
                if($posts->num_rows()<=0){
                    ?>
                    <div class="alert alert-warning"><?php echo lang_key('post_not_found'); ?></div>
                <?php
                }
                else
                    foreach($posts->result() as $news){
                        $news_url = post_detail_url($news); 
                        $title = $news->title;
                        $desc = $news->description;
                        ?>

                        <!-- Blog item starts -->
                        <div class="blog-one-item row">
                            <!-- blog One Img -->
                            <div class="blog-one-img col-md-3 col-sm-3 col-xs-12">
                                <!-- Image -->
                                <a href="<?php echo $news_url;?>"><img src="<?php echo $news->media;?>" alt="" class="img-responsive img-thumbnail" /></a>
                            </div>
                            <!-- blog One Content -->
                            <div class="blog-one-content  col-md-9 col-sm-9 col-xs-12">
                                <!-- Heading -->
                                <h3><a href="<?php echo $news_url;?>"><?php echo $title;?></a></h3>
                                <!-- Blog meta -->
                                <div class="blog-meta">
                                    <!-- Author -->
                                    <i class="fa fa-chain"></i> &nbsp; <a href="<?php echo source_news_url($news->source_id,get_source_title_by_id($news->source_id));?>"><?php echo get_source_title_by_id($news->source_id); ?></a> &nbsp;
                                    <!-- Date -->
                                    <i class="fa fa-calendar"></i> &nbsp; <a href="<?php echo date_news_url($news->publish_time);?>"><?php echo translateable_date($news->publish_time); ?></a>

                                </div>
                                <!-- Paragraph -->
                                <p><?php echo truncate(strip_tags($desc),100,'&nbsp;<a href="'.$news_url.'">...'.lang_key('view_more').'</a>',false);?></p>
                            </div>
                        </div>
                        <!-- Blog item ends -->
                    <?php } ?>
                <?php render_widgets('all_news_page');?>    
                <ul class="pagination">
                    <?php echo (isset($pages))?$pages:'';?>
                </ul>


            </div>


            <div class="col-md-3 col-sm-12 col-xs-12">
                <div class="sidebar">
                    <?php render_widgets('right_bar_all_news');?>
                </div>
            </div>

        </div>
    </div>

</div> 
<!-- Go to www.addthis.com/dashboard to customize your tools -->
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-53fb1205151cc4cf"></script>
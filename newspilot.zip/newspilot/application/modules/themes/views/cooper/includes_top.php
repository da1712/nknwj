<?php 
$compress_css = get_settings('site_settings','css_compression','No');
if($compress_css=='Yes')
{
?>
<link href="<?php echo theme_url();?>/assets/css/all-css.php" rel="stylesheet" type="text/css" />
<?php
}
else
{
?>
    <link href="<?php echo theme_url();?>/assets/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo theme_url();?>/assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo theme_url();?>/assets/css/jquery.mCustomScrollbar.css">
    <link href="<?php echo theme_url();?>/assets/css/styles/style.css" rel="stylesheet">
    <link href="<?php echo theme_url();?>/assets/css/styles/skin-lblue.css" rel="stylesheet" id="color_theme">
    <link href="<?php echo theme_url();?>/assets/css/custom.css" rel="stylesheet">
    <link href="<?php echo theme_url();?>/assets/css/custom-style.css" rel="stylesheet">
    <link href="<?php echo theme_url();?>/assets/css/mega-menu.css" rel="stylesheet">
    <link href="<?php echo theme_url();?>/assets/css/ionicons.min.css" rel="stylesheet">
    <link href="<?php echo theme_url();?>/assets/css/jquery.marquee.min.css" rel="stylesheet">
    <link href="<?php echo theme_url();?>/assets/css/owl.carousel.css" rel="stylesheet">
    <link href="<?php echo theme_url();?>/assets/css/owl.theme.default.min.css" rel="stylesheet">
<?php
}
?>

<?php 
$compress_js  = get_settings('site_settings','js_compression','No');
if($compress_js=='Yes')
{
?>
<script src="<?php echo theme_url();?>/assets/js/all_head_js.php"></script>
<?php if(get_settings('global_settings','lazy_load_images','No')=='Yes'){?>
<script async src="<?php echo theme_url();?>/assets/js/jquery.lazy.min.js"></script>
<?php }?>
<?php
}
else
{
?>
<script src="<?php echo theme_url();?>/assets/js/jquery-2.1.1.min.js"></script>
<script src="<?php echo theme_url();?>/assets/js/jquery.lazyload.js"></script>
<script src="<?php echo theme_url();?>/assets/js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo theme_url();?>/assets/js/owl.carousel.min.js"></script>
<script src='<?php echo theme_url();?>/assets/js/jquery.marquee.min.js'></script>
<?php if(get_settings('global_settings','lazy_load_images','No')=='Yes'){?>
<script src="<?php echo theme_url();?>/assets/js/jquery.lazy.min.js"></script>
<?php }?>
<?php 
}
?>
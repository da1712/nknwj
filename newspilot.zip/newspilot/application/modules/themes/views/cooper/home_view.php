<?php
$search_active = get_settings('global_settings', 'show_home_page_search', 'yes');
if($search_active == 'yes')
{
  //  require 'home_custom_search.php';
}
?>

<!-- Container -->
<div class="container main-container">

    <div class="row">

        <div class="col-md-8 col-sm-12 col-xs-12 content-panel">
            <?php render_widgets('home_page');?>
        </div>


        <div class="col-md-4 col-sm-12 col-xs-12">
            <div class="sidebar">
                <?php require_once'sidebar.php';?>                   
            </div>
        </div>

    </div>
</div>

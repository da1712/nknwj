<?php
header('Content-Type: application/javascript');
require 'jsmin.php';
$js_files = array('jquery-2.1.1.min.js','jquery.lazyload.js','jquery-migrate-1.2.1.min.js','owl.carousel.min.js','jquery.marquee.min.js');
function readff($file)
{
	$myfile = fopen($file, "r") or die("Unable to open file!");
	$data 	= fread($myfile,filesize($file));
	fclose($myfile);
	return $data;
}
	
foreach ($js_files as $js_file) {
	echo JSMin::minify(readff($js_file));
}

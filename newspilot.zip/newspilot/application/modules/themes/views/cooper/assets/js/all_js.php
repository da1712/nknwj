<?php
header('Content-Type: application/javascript');
require 'jsmin.php';
$js_files = array('bootstrap.min.js','main.js','html5shiv.js','megamenu.js','custom.js','jquery.mCustomScrollbar.concat.min.js','waypoints.min.js','jquery.countTo.js');
function readff($file)
{
	$myfile = fopen($file, "r") or die("Unable to open file!");
	$data 	= fread($myfile,filesize($file));
	fclose($myfile);
	return $data;
}
	
foreach ($js_files as $js_file) {
	echo JSMin::minify(readff($js_file));
}

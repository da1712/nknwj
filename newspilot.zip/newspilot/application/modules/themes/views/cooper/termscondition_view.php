<div class="page-heading-two">
    <div class="container">
        <h2><?php echo lang_key('terms_and_conditions'); ?> <span>&nbsp;</span></h2>        
        <div class="clearfix"></div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <p>Lorem ipsum doller sit amet. Lorem ipsum doller sit amet. Lorem ipsum doller sit amet. Lorem ipsum doller sit amet. Lorem ipsum doller sit amet. Lorem ipsum doller sit amet. 
            Lorem ipsum doller sit amet. Lorem ipsum doller sit amet. Lorem ipsum doller sit amet. Lorem ipsum doller sit amet. Lorem ipsum doller sit amet. 
        Lorem ipsum doller sit amet. Lorem ipsum doller sit amet. Lorem ipsum doller sit amet. 
            </p>
            <ol>
                <li>Lorem ipsum doller</li>
                <li>Lorem ipsum doller</li>
                <li>Lorem ipsum doller</li>
                <li>Lorem ipsum doller</li>
            </ol> 
        </div>    
    </div> <!-- /row -->
</div>
<div class="page-heading-two">
    <div class="container">
        <div class="clearfix"></div>
    </div>
</div>
<div class="container content-panel">
    <div class="row">
        <div class="col-md-12">
            <div class="">
                <div class="">
                	<?php echo $this->session->flashdata('msg');?>
                </div>
            </div>
        </div>
    </div> <!-- /row -->
</div>


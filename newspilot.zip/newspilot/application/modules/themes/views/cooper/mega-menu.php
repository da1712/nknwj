    <div class="menu-container">
        <div class="menu">
            <ul>
                        <?php
                            $CI = get_instance();
                            $CI->load->model('admin/page_model');
                            $CI->page_model->init();
                        ?>



                        <?php 
                            $alias = (isset($alias))?$alias:'';
                            foreach ($CI->page_model->get_menu() as $li) 
                            {
                                if($li->parent==0)
                                $CI->page_model->render_top_menu($li->id,0,$alias);
                            }
                        ?>

                        <?php 
                        if(get_settings('global_settings','show_cat_menu','Yes')=='Yes')
                        {
                        ?>
                        <li>
                            <a aria-expanded="false" aria-haspopup="true" role="button" data-toggle="dropdown" class="dropdown-toggle" href="#">
                              <?php echo lang_key('categories');?><span class="caret"></span></a>
                            <ul>
                            <?php
                            $CI = get_instance();
                            $CI->load->model('show/post_model');
                            $parent_categories = $CI->post_model->get_all_parent_categories();
                            $cat_count = 0;
                            foreach ($parent_categories->result() as $category) {
                              $cat_count++;
                              $category_url = category_news_url($category->id,$category->title);
                            ?>    
                              <li>
                                <?php
                                $child_categories = $CI->post_model->get_all_child_categories($category->id,5);
                                $total = $child_categories->num_rows();
                                ?>

                                  <a href="<?php echo $category_url;?>"><?php echo $category->title;?>
                                        <span dir="rtl" class="category-counter color">(<?php echo count_news_by_category($category->id);?>)
                                        </span>
                                        <?php if($total>0){?>
                                        <span class="caret-right"></span>
                                        <?php }?>
                                  </a>
                                <?php if($total>0){?>
                                  <ul>
                                      <?php foreach ($child_categories->result() as $child) { 
                                         $sub_category_url = category_news_url($child->id,$child->title);
                                      ?>
                                      <li><a tabindex="-1" href="<?php echo $sub_category_url;?>"><?php echo $child->title;?>
                                        <span dir="rtl" class="category-counter color">(<?php echo count_news_by_subcategory($child->id);?>)</span>
                                      </a></li>
                                      <?php }?>
                                    <?php if($total>=5){?>
                                      <li><a class="see_all_sub_cat_menu" tabindex="-1" href="<?php echo site_url('show/allsubcat/'.$category->id);?>"><?php echo lang_key('view_all');?></a></li>
                                    <?php }?>
                                  </ul>
                                <?php }?>      
                              </li>
                              <?php if($cat_count%4==0){ ?>
                              <div class="clearfix"></div>
                              <?php }?>
                            <?php 
                            }
                            ?>
                            </ul>
                        </li>
                        <?php
                        }
                        ?>

                        <?php 
                        if(get_settings('global_settings','show_source_menu','Yes')=='Yes')
                        {
                        ?>
                        <li>
                            <a aria-expanded="false" aria-haspopup="true" role="button" data-toggle="dropdown" class="dropdown-toggle" href="#">
                              <?php echo lang_key('news_sources');?><span class="caret"></span></a>
                            <ul>
                            <?php
                            $CI = get_instance();
                            $CI->load->model('admin/content_model');
                            $sources = $CI->content_model->get_all_sources();
                            foreach ($sources->result() as $source) {
                              $source_news_url = source_news_url($source->id,$source->source_name);
                            ?>    
                              <li>
                                  <a href="<?php echo $source_news_url;?>"><?php echo $source->source_name;?></a>
                              </li>
                            <?php 
                            }
                            ?>
                            </ul>
                        </li>
                        <?php
                        }
                        ?>

                        
                        <?php if(!is_loggedin()){?>
                        <?php if(get_settings('global_settings','enable_signup','Yes')=='Yes'){?>
                        <li class="">
                            <a class="signup" href="<?php echo site_url('account/signupform');?>"><?php echo lang_key('signup')?></a>
                        </li>
                        <?php }?>

                        <li class="">
                            <a class="signin" href="#"><?php echo lang_key('signin');?></a>
                        </li>
                        <?php }else{ ?>
                        <?php if(is_admin() || is_moderator()){?>
                        <li class="">
                            <a class="signup" href="<?php echo site_url('admin');?>"><?php echo lang_key('user_panel');?></a>
                        </li>
                        <?php }else if(is_generaluser()){?>
                        <li class="">
                            <a class="signup" href="<?php echo site_url('admin/editprofile');?>"><?php echo lang_key('user_panel');?></a>
                        </li>
                        <?php }?>
                        <li class="">
                            <a class="signup" href="<?php echo site_url('account/logout');?>"><?php echo lang_key('logout');?></a>
                        </li>
                        <?php }?>
            </ul>
        </div>
    </div>

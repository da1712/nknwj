<div class="page-heading-two">
    <div class="container">
        <h2><?php echo lang_key('confirmation'); ?> <span>&nbsp;</span></h2>        
        <div class="clearfix"></div>
    </div>
</div>
<div class="container">
	<div class="row">
	    <div class="col-md-12 min-height-default">
	        <div class="alert alert-info">
	            <?php echo lang_key('reg_success_message'); ?>
	        </div>
	    </div>    
	</div> <!-- /row -->
</div>
<?php
render_widget($widget_name);